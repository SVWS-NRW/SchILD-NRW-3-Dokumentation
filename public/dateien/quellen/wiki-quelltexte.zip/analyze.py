import json,re,collections,pathlib,urllib.parse,csv
R=pathlib.Path(__file__).parent
def read(n):return json.loads((R/n).read_text())
def write(n,d): (R/n).write_text(json.dumps(d,ensure_ascii=False,indent=2))
def raw(v):return v.get('revisions',[{}])[0].get('slots',{}).get('main',{}).get('*','')
def norm(t):
    t=urllib.parse.unquote(t).replace('_',' ').strip().split('#')[0]
    t=re.sub(r'^(File|Image|Bild|Medium|Media):','Datei:',t,flags=re.I)
    t=re.sub(r' +',' ',t)
    if ':' in t:
        ns,tail=t.split(':',1); t=ns+':'+tail[:1].upper()+tail[1:]
    return t[:1].upper()+t[1:]
P=read('pages.json');B={v['title']:v for v in P.values()};INV=read('inventory.json');ALL={v['title']:v for v in INV};F=read('files.json')
roots=['SchILD-NRW 3','Reportdesigner - Schnelleinstieg']
reach=set();todo=roots[:]
while todo:
 t=todo.pop()
 if t in reach or t not in B:continue
 reach.add(t);todo += [x['title'] for x in B[t].get('links',[]) if x['ns']==0]
direct={x['title'] for x in B[roots[0]].get('links',[]) if x['ns']==0}
external={'SVWS-Server','SVWS-Client','Installation SVWS-Server','Installation SVWS-Server unter Linux (Installation)','Troubleshooting Installation SVWS-Server'}
editor={'Beispiel zum Bildereinbinden','Vorgaben für Wiki-Autoren','Musterseite für Wiki-Autoren'}
tests={'Kachel Beispielseite','SchILD-NRW 3 - Anwenderhandbuch'}
archive={'Basisreportsammlung: Leistungsübersicht Jg. 05 bis EF','Basisreportsammlung: Leistungsübersicht Jg. Q1 bis Q2'}
rows=[]
for t,v in sorted(B.items()):
 if v['ns']!=0:continue
 w=raw(v);cats=[x['title'] for x in v.get('categories',[])];rd=re.match(r'\s*#(?:REDIRECT|WEITERLEITUNG)\s*\[\[([^\]]+)\]\]',w,re.I)
 flags=[]
 if rd:kind='alias';reason='Weiterleitungsziel erhalten; keinen doppelten Artikel erzeugen'
 elif not w.strip():kind='empty';reason='Leere Seite; Quelle dokumentieren, fehlenden Inhalt nicht erfinden'
 elif t in external:kind='external-reference';reason='SVWS-eigenes Thema; Verweis auf doku.svws-nrw.de, Quelle im Archiv erhalten'
 elif t in editor:kind='editorial';reason='Autorenhilfe; getrennt von der Anwenderdokumentation übernehmen/adaptieren'
 elif t in tests:kind='test-archive';reason='Im Quelltext ausdrücklich als Seitentest gekennzeichnet; nicht als fertige Dokumentation publizieren'
 elif t=='Erklärung zur Barrierefreiheit':kind='legal-review';reason='Auf neuen Webauftritt und Zuständigkeit abstimmen; keine unveränderte Übernahme'
 elif t in archive:kind='reporting-archive-review';reason='Ältere Leistungsübersicht neben neueren Seiten; Inhalte vergleichen, nichts vorab verwerfen'
 elif t=='Externes Notenmodul 3 (Tutorial)':kind='unfinished-review';reason='Nur leere Abschnittsüberschriften und Kategorie UNFERTIG; mit ENM-Anleitung abgleichen'
 elif 'Kategorie:RAP-Funktionen' in cats:kind='reporting-reference';reason='RAP-Funktionsreferenz für Reporting vollständig sichern; SchILD-3-Kompatibilität gesondert prüfen'
 elif any(c in cats for c in ('Kategorie:Reportdesigner','Kategorie:Reportverwaltung','Kategorie:Basisreportsammlung')) or t=='Reportdesigner':kind='reporting';reason='Reporting, Formularverwaltung, Zeugnisse oder Basisreports als SchILD-3-Arbeitsbestand'
 else:kind='schild3';reason='SchILD-3-Fachartikel oder notwendige Bedien-/Installations-/Migrationsanleitung'
 if t not in direct:flags.append('nicht-direkt-von-startseite')
 if t not in reach:flags.append('ausserhalb-beider-einstiegsgraphen')
 if any(c in cats for c in ('Kategorie:UNFERTIG','Kategorie:BETA','Kategorie:Beta','Kategorie:ERWEITERBAR')):flags.append('redaktioneller-quellstatus')
 if re.search(r'Sch[Ii]LD[ -]*(?:NRW[ -]*)?2',w): flags.append('schild2-bezug-pruefen-kein-ausschluss')
 if t in ('Hinweise für IT-Dienstleister','FAQ','Installation SVWS-Server und SchILD-NRW 3') or 'Kategorie:SVWS-Server' in cats:flags.append('schild-server-grenze-pruefen')
 if not rd and re.search(r'\b(?:Beta(?:version|stadium)?|202[0-4])\b',w,re.I):flags.append('zeitstand-pruefen')
 rev=v.get('revisions',[{}])[0]
 rows.append(dict(pageid=v['pageid'],title=t,status=kind,reason=reason,direct=t in direct,reachable=t in reach,flags=flags,categories=cats,revision=rev.get('revid'),timestamp=rev.get('timestamp'),source=v['fullurl'],redirect=rd.group(1) if rd else '',characters=len(w)))
active={x['title'] for x in rows if x['status'] in ('schild3','reporting','reporting-reference','reporting-archive-review','unfinished-review','alias')}
templates=set();todo=list(active)
while todo:
 t=todo.pop()
 for q in B.get(t,{}).get('templates',[]):
  qt=q['title']
  if qt not in templates: templates.add(qt);todo.append(qt)
usedby=collections.defaultdict(set);externalby=collections.defaultdict(set);missingby=collections.defaultdict(set)
for t in sorted(active|templates):
 v=B.get(t,{})
 for im in v.get('images',[]): usedby[norm(im['title'])].add(t)
 for q in v.get('links',[]):
  if q['ns']==6:usedby[norm(q['title'])].add(t)
  elif q['ns']==0 and q['title'] not in ALL:missingby[q['title']].add(t)
 for m in re.finditer(r'\[\[\s*(?:Datei|File|Bild|Image|Medium|Media):([^\[\]\n|]+)',raw(v),re.I):
  if '{{' not in m.group(1):usedby[norm('Datei:'+m.group(1))].add(t)
 for e in v.get('extlinks',[]): externalby[e['*']].add(t)
urlmap={urllib.parse.unquote(f['url']):norm('Datei:'+f['name']) for f in F}
for u,ts in externalby.items():
 if urllib.parse.unquote(u) in urlmap:usedby[urlmap[urllib.parse.unquote(u)]].update(ts)
files=[]
for f in F:
 title=norm('Datei:'+f['name']);users=sorted(usedby.get(title,[]))
 files.append(dict(title=title,status='required' if users else 'unassigned-review',mime=f['mime'],size=f['size'],sha1=f['sha1'],timestamp=f['timestamp'],url=f['url'],descriptionurl=f.get('descriptionurl'),used_by=users))
extensions=re.compile(r'\.(?:pdf|zip|7z|rar|rtm|rtf|docx?|odt|xlsx?|ods|csv|txt|pptx?|exe|msi|sh)(?:$|[?#])',re.I)
ext=[]
for u,ts in sorted(externalby.items()):
 kind='linked-download' if extensions.search(u) else 'external-reference'
 if re.search(r'github\.com/.+/(?:releases|raw|blob)|schulverwaltungsinfos\.nrw\.de/.+(?:download|zip)',u,re.I):kind='download-source'
 ext.append(dict(url=u,kind=kind,used_by=sorted(ts),verification='inventoried-not-downloaded'))
template_rows=[]
for t,v in sorted(B.items()):
 if v['ns']!=10:continue
 template_rows.append(dict(title=t,status='required' if t in templates else 'unused-review',characters=len(raw(v)),revision=v.get('revisions',[{}])[0].get('revid'),used_by=sorted(s for s in active|templates if t!=s and any(q['title']==t for q in B.get(s,{}).get('templates',[])))))
summary=dict(inventory_total=len(INV),namespace_counts=dict(collections.Counter(x['ns'] for x in INV)),main_total=len(rows),direct_from_schild3=len(direct),reachable_from_both=len(reach),unreachable_main=sum(not x['reachable'] for x in rows),statuses=dict(collections.Counter(x['status'] for x in rows)),templates_total=len(template_rows),templates_required=len(templates),files_total=len(files),files_required=sum(x['status']=='required' for x in files),missing_files=[{'title':t,'used_by':sorted(ts)} for t,ts in sorted(usedby.items()) if t not in {x['title'] for x in files}],external_total=len(ext),external_types=dict(collections.Counter(x['kind'] for x in ext)),missing_internal=[dict(title=t,used_by=sorted(ts)) for t,ts in sorted(missingby.items())])
write('scope-pages.json',rows);write('scope-files.json',files);write('scope-templates.json',template_rows);write('scope-external.json',ext);write('summary.json',summary)
for name,data in [('Seiten',rows),('Dateien',files),('Vorlagen',template_rows),('Externe-Verweise',ext)]:
 if not data:continue
 with (R/(name+'.csv')).open('w',encoding='utf-8-sig',newline='') as f:
  cw=csv.DictWriter(f,fieldnames=list(data[0]),delimiter=';');cw.writeheader()
  cw.writerows({k:' | '.join(map(str,v)) if isinstance(v,list) else v for k,v in d.items()} for d in data)
write('not-reachable.json',[x for x in rows if not x['reachable']])
print(json.dumps({k:v for k,v in summary.items() if k not in ('missing_files','missing_internal')},ensure_ascii=False,indent=2))
print('MISSING FILES',len(summary['missing_files']),json.dumps(summary['missing_files'],ensure_ascii=False))
print('MISSING LINKS',len(summary['missing_internal']),json.dumps(summary['missing_internal'],ensure_ascii=False))
