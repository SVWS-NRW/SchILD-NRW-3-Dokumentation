# SchILD-3-Zielbestand – Abgrenzung und Prüflisten

Erhebung: 18.10.2026. Quelle: öffentlich lesbares MediaWiki „Schulverwaltungssoftware“. Ziel: VitePress im Repository `Raffenberg/SchILD3_Doku`.

## Ergebnis und Abgrenzungsentscheidung

Der reguläre Zielbestand umfasst **444 fachliche Seiten**: 272 SchILD-3-Fachartikel, 50 Reporting-Artikel und 122 RAP-Funktionsseiten. Zusätzlich werden zwei ältere Reporting-Varianten, ein unfertiger ENM-Artikel und neun Weiterleitungen gesichert und getrennt bearbeitet. Es wird nichts wegen fehlender Verlinkung verworfen.

| Teilbestand | Seiten | Behandlung |
|---|---:|---|
| SchILD-3-Fachartikel | 272 | `schild3` im Manifest |
| Reporting und Reportverwaltung | 50 | `reporting` im Manifest |
| RAP-Funktionsreferenz | 122 | `reporting-reference` im Manifest |
| Ältere Reporting-Varianten: Inhaltsvergleich | 2 | `reporting-archive-review` im Manifest |
| Unfertiger ENM-Artikel: ergänzen/zusammenführen | 1 | `unfinished-review` im Manifest |
| Weiterleitungen: Alias erhalten | 9 | `alias` im Manifest |
| SVWS-Themen: externe Referenz | 5 | `external-reference` im Manifest |
| Autorenhilfen: eigener Redaktionsbereich | 3 | `editorial` im Manifest |
| Barrierefreiheit: redaktionell abstimmen | 1 | `legal-review` im Manifest |
| Seitentests: nur Quellarchiv | 2 | `test-archive` im Manifest |
| Leere Seiten: dokumentieren | 2 | `empty` im Manifest |

Alle 469 Titel im Artikelnamensraum besitzen genau eine Zuordnung. „Regulärer Zielbestand“ bedeutet Übernahmekandidat für die Migration, keine fachliche Freigabe jeder Aussage. Die spätere Gliederung wird unabhängig von alten Wiki-Titeln festgelegt.

## Erhebungsweg und Vollständigkeit

- `allpages` wurde für alle realen Namensräume (0 bis 15) mit vollständiger Fortsetzung abgefragt: **1551 Einträge**. Diskussionen und Benutzerseiten sind nur als Inventareinträge erfasst, nicht Teil der Anwenderdokumentation.
- Bestand: 469 Artikelseiten, 1.033 Dateiseiten, 31 Vorlagen, 7 Kategorie-Beschreibungsseiten, 7 MediaWiki-Seiten, 2 Projektseiten, 1 Diskussionsseite und 1 Benutzerseite. Die 7 Kategorie-Beschreibungsseiten sind nicht die Zahl aller verwendeten Kategorien.
- Alle 469 Artikelquelltexte, alle Vorlagen, die vorhandenen Kategorie-/System-/Projektquelltexte sowie die Beschreibungen sämtlicher 1.033 Dateien wurden gelesen und im Quellarchiv gesichert. 109 Dateibeschreibungen enthalten Text, dort wurden keine weiteren Wiki- oder HTTP-Verknüpfungen gefunden.
- Quellen enthalten Revisionsnummer, Bearbeitungszeit, URL und Abhängigkeiten. Es wird jeweils die aktuelle Revision gesichert, nicht die gesamte Versionsgeschichte. Die Erhebung ist kein atomarer Datenbank-Snapshot.
- SchILD-3-Startseite: 283 direkte Artikelziele. Von SchILD-3-Startseite und Reporting-Schnelleinstieg aus sind rekursiv 446 vorhandene Artikel erreichbar; 23 bleiben unerreicht. Der Graph verwendet nur Artikelverweise aus Seiteninhalten, nicht die globale Navigation oder beliebige Rückverweise.
- Alle 186 nicht direkt von der SchILD-3-Startseite verlinkten Artikelseiten wurden anhand von Quelltext-/Kategorie-/Verknüpfungsmerkmalen mitgeprüft. Die 23 außerhalb beider Einstiegsgraphen wurden zusätzlich einzeln beurteilt (Liste unten).
- Kategorien unterstützen die Zuordnung, ersetzen aber weder Inventar noch Inhaltsprüfung. Fehlende Kategorien und SchILD-2-Bezüge führen nicht zum Ausschluss.

## SchILD 3 und SVWS-Server

SchILD-Bedienung, Einstellungen, Migration aus SchILD 2, lokale Installation, Arbeitsverzeichnisse und die erforderlichen Server-Voraussetzungen bleiben im Zielbestand. Die gemischte Installationsanleitung wird bei der Redaktion aufgeteilt: SchILD-spezifische Schritte behalten, eigenständige Serveradministration mit der SVWS-Dokumentation abgleichen und dorthin verweisen.

Die fünf eigenständigen Wiki-Seiten zu SVWS-Server, SVWS-Client, Serverinstallation, Linuxinstallation und Server-Troubleshooting werden als Quellbestand gesichert, für die neue Anwenderdokumentation jedoch als externe Referenz auf `https://doku.svws-nrw.de/` behandelt. Das ist eine Abgrenzungsempfehlung; bei nur im Wiki enthaltenen SchILD-relevanten Hinweisen ist der Abschnitt vor einer Zusammenführung zu erhalten.

## Reporting und Vorlagen

Zum Ziel gehören Reportverwaltung und Schnellzugriff, Reportdesigner-Grundlagen, Anpassung und Erstellung von Reports, Datenquellen, Programmierung, Basisreports, Serienbriefe, Zeugnisdruck und die vollständige RAP-Funktionsreferenz. Die 122 RAP-Seiten werden getrennt als Nachschlagewerk geführt. Ihre Zuordnung bestätigt noch nicht die Funktionskompatibilität jeder dokumentierten Funktion mit SchILD 3.

SchILD-2-Vergleiche, Umstellungshinweise und historische Versionsinformationen bleiben erhalten und erhalten bei Bedarf eine Archiv-/Versionskennzeichnung. Für 22 Artikel wurde ein SchILD-2-Bezug markiert; das ist ein Suchhinweis, keine Aussage über deren Veraltung.

Zwei nicht mehr eingebundene Leistungsübersicht-Artikel stammen in der gesicherten Revision vom 16.07.2026. Die entsprechenden neueren Varianten wurden am 14.10.2026 bearbeitet und beschreiben unter anderem zusätzliche Teilleistungsreports. Deshalb Quelltexte vergleichen und einzigartige Erläuterungen/Parameter übertragen, bevor ältere Artikel zusammengeführt werden.

31 vorhandene MediaWiki-Vorlagen sind inventarisiert; **21 sind im fachlichen Zielbestand direkt oder transitiv eingebunden**. Die Vorlagen werden semantisch nach VitePress übertragen: Wichtig/Achtung/Tipp/Hinweis und weitere Infoboxen, Layout-/Umflusssteuerung sowie alphabetische Navigation. Titel und Inhalte der Boxen müssen erhalten bleiben; alte HTML- und CSS-Strukturen müssen nicht identisch nachgebaut werden. Nicht verwendete Vorlagen bleiben im Quellarchiv. Die unbenutzten Vorlagen `Button` und `Video` sind leer.

## Dateien, Downloads und Videos

**855 von 1.033 Wiki-Dateien** sind als Abhängigkeit der ausgewählten Artikel einschließlich Prüffällen und eingebundener Vorlagen nachgewiesen. Dateimanifest: Original-URL, MIME-Typ, Größe, MediaWiki-SHA1, Zeitstempel und verwendende Seiten. Unter den benötigten Dateien sind auch ein ZIP sowie eine ODS- und eine XLSX-Datei. Dateinamen wurden nach MediaWiki-Regeln einschließlich erster Großschreibung und Leerzeichen normalisiert; dadurch gibt es im ermittelten Abhängigkeitsbestand keine fehlende hochgeladene Datei.

**178 Dateien ohne nachgewiesenen Bezug** bleiben als `unassigned-review` erhalten. Dies ist weder eine Löschfreigabe noch ein Beleg für Veraltung. Darunter befinden sich SchILD-, Reporting- und ENM-Bilder, LuPO-Bilder, Serverabbildungen, Autorenbeispiele sowie ein Client-Deinstallations-ZIP. Einzigartige Informationen aus solchen Dateien sind vor einem späteren Ausschluss gesondert zu prüfen. Eine visuelle Einzelprüfung aller 178 Bilder gehört noch zur redaktionellen Prüfung.

Es wurden 30 unterschiedliche von MediaWiki gemeldete externe URLs erfasst: 9 Downloadquellen, 1 direkter PDF-Download und 20 sonstige Verweise. Zusätzlich enthält `raw-url-occurrences.json` sämtliche 47 unterschiedlichen HTTP-Quelltextvorkommen aus dem fachlichen Zielbestand, einschließlich Beispieladressen, Syntaxfehlern und vom Linkindex nicht gemeldeten URLs. Diese werden nicht ungeprüft als gültige Downloadziele übernommen.

YouTube-Erweiterungstags: **17 Einbettungen / 16 unterschiedliche Video-IDs**. Kennungen, Ursprungsseiten und Korrekturhinweise sind in `videos.json` gesichert. Medien werden bei der Migration als Verweis/Einbettung berücksichtigt; die Videodateien wurden nicht heruntergeladen.

Die GitHub-Release-Metadaten wurden am Erhebungstag geprüft:

| Paket | Release | Artefakt |
|---|---|---|
| SVWS-NRW/Schild-NRW-3-Reports | v1.1.1 | [Basisreports-SchILD-NRW3-v1.1.1-14.10.2026.zip](https://github.com/SVWS-NRW/Schild-NRW-3-Reports/releases/download/v1.1.1/Basisreports-SchILD-NRW3-v1.1.1-14.10.2026.zip) |
| SVWS-NRW/Schild-NRW-3-Zeugnisse-GS | v1.0.0 | [GS-Zeugnisse-NRW3-v1.0.0-20.01.2026.zip](https://github.com/SVWS-NRW/Schild-NRW-3-Zeugnisse-GS/releases/download/v1.0.0/GS-Zeugnisse-NRW3-v1.0.0-20.01.2026.zip) |
| SVWS-NRW/Schild-NRW-3-Zeugnisse-BK | v1.0.2 | [BK-Zeugnisse-Schild-NRW3-v1.0.2-02.09.2026.zip](https://github.com/SVWS-NRW/Schild-NRW-3-Zeugnisse-BK/releases/download/v1.0.2/BK-Zeugnisse-Schild-NRW3-v1.0.2-02.09.2026.zip) |
| ExternesNotenmodul (Vorabversion) | 0.9.2.0 | [nm3_setup.exe](https://github.com/SVWS-NRW/ExternesNotenmodul/releases/download/0.9.2.0/nm3_setup.exe) |
| ExternesNotenmodul (Vorabversion) | 0.9.2.0 | [nm3_setup.zip](https://github.com/SVWS-NRW/ExternesNotenmodul/releases/download/0.9.2.0/nm3_setup.zip) |
| ExternesNotenmodul (Vorabversion) | 0.9.2.0 | [nm3_versionshinweise.pdf](https://github.com/SVWS-NRW/ExternesNotenmodul/releases/download/0.9.2.0/nm3_versionshinweise.pdf) |

Die Paketdateien gehören als externe Bezugsquellen zum Abhängigkeitsmanifest. Historische/beta-bezogene Releaseverweise bleiben mit Quellnachweis erfasst. Es wurden noch keine ZIP-, Report-, Office-, PDF- oder Installationsdateien vollständig heruntergeladen oder entpackt; Dateiinhalte innerhalb dieser Pakete sind deshalb noch nicht inventarisiert. Der vollständige Dateidownload und die Entpackprüfung bilden den anschließenden Sicherungsschritt.

## Nicht aus beiden Einstiegsseiten erreichbare Artikel

| Artikel | Entscheidung |
|---|---|
| [Backup des SVWS-Servers](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Backup_des_SVWS-Servers) | Weiterleitungen: Alias erhalten: Weiterleitungsziel erhalten; keinen doppelten Artikel erzeugen |
| [Basisreportsammlung: Leistungsübersicht Jg. 05 bis EF](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Basisreportsammlung:_Leistungs%C3%BCbersicht_Jg._05_bis_EF) | Ältere Reporting-Varianten: Inhaltsvergleich: Ältere Leistungsübersicht neben neueren Seiten; Inhalte vergleichen, nichts vorab verwerfen |
| [Basisreportsammlung: Leistungsübersicht Jg. Q1 bis Q2](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Basisreportsammlung:_Leistungs%C3%BCbersicht_Jg._Q1_bis_Q2) | Ältere Reporting-Varianten: Inhaltsvergleich: Ältere Leistungsübersicht neben neueren Seiten; Inhalte vergleichen, nichts vorab verwerfen |
| [Beispiel zum Bildereinbinden](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Beispiel_zum_Bildereinbinden) | Autorenhilfen: eigener Redaktionsbereich: Autorenhilfe; getrennt von der Anwenderdokumentation übernehmen/adaptieren |
| [Benutzeroberfläche von SchILD-NRW 3](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Benutzeroberfl%C3%A4che_von_SchILD-NRW_3) | SchILD-3-Fachartikel: SchILD-3-Fachartikel oder notwendige Bedien-/Installations-/Migrationsanleitung |
| [Erklärung zur Barrierefreiheit](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Erkl%C3%A4rung_zur_Barrierefreiheit) | Barrierefreiheit: redaktionell abstimmen: Auf neuen Webauftritt und Zuständigkeit abstimmen; keine unveränderte Übernahme |
| [Export (Verwaltung)](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Export_(Verwaltung)) | Weiterleitungen: Alias erhalten: Weiterleitungsziel erhalten; keinen doppelten Artikel erzeugen |
| [Externes Notenmodul 3 (Tutorial)](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Externes_Notenmodul_3_(Tutorial)) | Unfertiger ENM-Artikel: ergänzen/zusammenführen: Nur leere Abschnittsüberschriften und Kategorie UNFERTIG; mit ENM-Anleitung abgleichen |
| [FAQ](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=FAQ) | SchILD-3-Fachartikel: SchILD-3-Fachartikel oder notwendige Bedien-/Installations-/Migrationsanleitung |
| [Hauptseite](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Hauptseite) | Leere Seiten: dokumentieren: Leere Seite; Quelle dokumentieren, fehlenden Inhalt nicht erfinden |
| [Import (Verwaltung)](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Import_(Verwaltung)) | Leere Seiten: dokumentieren: Leere Seite; Quelle dokumentieren, fehlenden Inhalt nicht erfinden |
| [Installation SVWS-Server](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Installation_SVWS-Server) | SVWS-Themen: externe Referenz: SVWS-eigenes Thema; Verweis auf doku.svws-nrw.de, Quelle im Archiv erhalten |
| [Installation SVWS-Server unter Linux (Installation)](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Installation_SVWS-Server_unter_Linux_(Installation)) | SVWS-Themen: externe Referenz: SVWS-eigenes Thema; Verweis auf doku.svws-nrw.de, Quelle im Archiv erhalten |
| [Installation des Externen Notenmoduls (Tutorial)](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Installation_des_Externen_Notenmoduls_(Tutorial)) | SchILD-3-Fachartikel: SchILD-3-Fachartikel oder notwendige Bedien-/Installations-/Migrationsanleitung |
| [Kachel Beispielseite](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Kachel_Beispielseite) | Seitentests: nur Quellarchiv: Im Quelltext ausdrücklich als Seitentest gekennzeichnet; nicht als fertige Dokumentation publizieren |
| [Komplette Abiturberechnungen durchführen (Einführung in SchILD-NRW)](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Komplette_Abiturberechnungen_durchf%C3%BChren_(Einf%C3%BChrung_in_SchILD-NRW)) | Weiterleitungen: Alias erhalten: Weiterleitungsziel erhalten; keinen doppelten Artikel erzeugen |
| [Musterseite für Wiki-Autoren](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Musterseite_f%C3%BCr_Wiki-Autoren) | Autorenhilfen: eigener Redaktionsbereich: Autorenhilfe; getrennt von der Anwenderdokumentation übernehmen/adaptieren |
| [SVWS-Client](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=SVWS-Client) | SVWS-Themen: externe Referenz: SVWS-eigenes Thema; Verweis auf doku.svws-nrw.de, Quelle im Archiv erhalten |
| [SVWS-Server](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=SVWS-Server) | SVWS-Themen: externe Referenz: SVWS-eigenes Thema; Verweis auf doku.svws-nrw.de, Quelle im Archiv erhalten |
| [SchILD-NRW 3 - Anwenderhandbuch](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=SchILD-NRW_3_-_Anwenderhandbuch) | Seitentests: nur Quellarchiv: Im Quelltext ausdrücklich als Seitentest gekennzeichnet; nicht als fertige Dokumentation publizieren |
| [Schuljahres-/Abschnittswechsel (Verwaltung Schule)](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Schuljahres-/Abschnittswechsel_(Verwaltung_Schule)) | Weiterleitungen: Alias erhalten: Weiterleitungsziel erhalten; keinen doppelten Artikel erzeugen |
| [Troubleshooting Installation SVWS-Server](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Troubleshooting_Installation_SVWS-Server) | SVWS-Themen: externe Referenz: SVWS-eigenes Thema; Verweis auf doku.svws-nrw.de, Quelle im Archiv erhalten |
| [Vorgaben für Wiki-Autoren](https://schulverwaltungsinfos.nrw.de/svws/wiki/index.php?title=Vorgaben_f%C3%BCr_Wiki-Autoren) | Autorenhilfen: eigener Redaktionsbereich: Autorenhilfe; getrennt von der Anwenderdokumentation übernehmen/adaptieren |

## Offene Reparatur- und Redaktionspunkte

- 18 unterschiedliche fehlende interne Artikelziele, jeweils mit Verursacherseite in `summary.json`. Davon sind 10 fehlerhaft als `Index.php?title=Kategorie:…` geschriebene Kategorieverweise und 8 fehlende Zielartikel in der Beschreibung der Benutzeroberfläche. Die Ziele sind als Quellfehler zu behandeln und auf vorhandene Fachartikel oder neue Bereichsübersichten umzulenken.
- Ein unvollständiges `[[Datei:` im Artikel E-Mail-Versand; Stelle in `malformed-source.json`.
- Fehlerhafte externe Linksyntax mit `|` in Schulbezogene Daten (Lehrkräfte) und in der Grundschulzeugnis-Vorbereitung. Nicht nur HTML-Links übernehmen, sondern auch Quelltextstellen reparieren.
- Zwei Videoeinträge haben an der Kennung zusätzliche Zeichen/Leerraum. Original und bereinigte Kennung sind im Manifest getrennt, der tatsächliche Wiedergabetest steht aus.
- ENM3-Tutorial enthält nur Überschriften und ist als UNFERTIG gekennzeichnet. Die eigenständige ENM-Installation ist ausführlicher und wurde zusätzlich aufgenommen. Diese Artikel zusammenführen/ergänzen; keine fehlenden Arbeitsschritte erfinden.
- FAQ, gemischte Server-/SchILD-Anleitungen und ältere Installations-/Betahinweise fachlich auf Aktualität prüfen.
- Barrierefreiheitserklärung und Projektseiten Datenschutz/Impressum an den neuen Webauftritt und dessen Zuständigkeit anpassen. Die Wiki-Erklärungen sind Quellbelege, keine automatisch gültigen Texte für die neue Website.
- Autorenhilfen gehören in einen eigenen Redaktionsbereich. Die beiden ausdrücklich so bezeichneten Seitentests werden nicht als fertige Anwenderdokumentation behandelt.

## Abgleich mit dem Fork

Der gelesene Git-Baum von `main` hat den Commit `6ffaf2b0fe25051292a4b8924742c1197099028a`. Er enthält das VitePress-Grundgerüst und eine Navigation, aber keine zu deren Verweisen gehörenden Artikeldateien. Ein AGENTS.md war im vollständigen Baum nicht vorhanden.

Die bestehende Sidebar enthält 486 Linkeinträge. 460 davon lassen sich nach vereinfachter Titelnormalisierung vorhandenen Wiki-Titeln zuordnen, 26 nicht. Das ist nur ein Kandidatenvergleich; die bereinigten Titel sind keine verlässlichen Quellidentitäten. Die Sidebar ist deshalb nicht die maßgebliche Bestandsliste oder endgültige Zielgliederung. Alle Details stehen in `sidebar-comparison.json`.

## Übergabe und nächster Schritt

`Zielbestand-Punkt2.zip` enthält Quelltexte und Inventar, die vier CSV-Prüflisten, JSON-Manifeste, Release-Metadaten und reproduzierbare Erfassungs-/Auswertungsskripte (Python-Standardbibliothek). `Seiten.csv` ordnet jeden Artikel zu; `Dateien.csv` ordnet jede hochgeladene Datei zu. Die vollständige Wiki-Versionsgeschichte, gerendertes HTML und die Binärdateien selbst sind noch nicht Teil dieser Sicherung.

Die Skripte lassen sich mit `python collect.py`, danach `python analyze.py` und `python extras.py` erneut ausführen. Für einen vollständig neuen Erhebungsstand zuvor `inventory.json` und `batches/` in einer Arbeitskopie entfernen; sonst werden bereits gesicherte Artikelbatches wiederverwendet. Release-Metadaten und Fork-Sidebar sind gesonderte Snapshots aus GitHub und werden von diesen Skripten nicht aktualisiert. `build_report.py` erstellt den Bericht und das Übergabe-ZIP aus diesen Quellen.

Als Nächstes: Originaldateien und verlinkte Pakete herunterladen, Prüfsummen vergleichen, Paketinhalt inventarisieren und HTML-/Vorlagenauflösung sichern. Danach erst die VitePress-Überführung mit stabilen Zielpfaden, Aliasliste und Inhaltsprüfung beginnen.
