import json, time, urllib.request, urllib.parse, pathlib, concurrent.futures
ROOT=pathlib.Path(__file__).parent
API='https://schulverwaltungsinfos.nrw.de/svws/wiki/api.php'
def api(**params):
    url=API+'?'+urllib.parse.urlencode(dict(action='query',format='json',**params))
    for attempt in range(4):
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'SchILD3-documentation-inventory/1.0 (read-only migration audit)'})
            with urllib.request.urlopen(req,timeout=60) as r: d=json.load(r)
            if 'error' in d: raise RuntimeError(d['error'])
            return d
        except Exception:
            if attempt==3: raise
            time.sleep(1+attempt)
def save(name,data):
    (ROOT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2))
def inventory(ns):
    out=[]; cont={}
    while True:
        d=api(list='allpages',apnamespace=ns,aplimit=500,**cont)
        out+=d.get('query',{}).get('allpages',[])
        if 'continue' not in d: break
        cont=d['continue']
    print('inventory namespace',ns,len(out),flush=True)
    return out
def batch(ids):
    path=ROOT/'batches'/('-'.join(map(str,ids))+'.json')
    if path.exists(): return json.loads(path.read_text())
    out={};cont={}
    while True:
        d=api(pageids='|'.join(map(str,ids)),prop='info|revisions|links|templates|images|extlinks|categories',inprop='url',rvprop='ids|timestamp|content',rvslots='main',pllimit='max',tllimit='max',imlimit='max',ellimit='max',cllimit='max',**cont)
        for k,v in d.get('query',{}).get('pages',{}).items():
            p=out.setdefault(k,{})
            for key,value in v.items():
                if isinstance(value,list):
                    dest=p.setdefault(key,[])
                    for item in value:
                        if item not in dest: dest.append(item)
                else: p[key]=value
        if 'continue' not in d: break
        cont=d['continue']
    path.write_text(json.dumps(out,ensure_ascii=False,indent=2))
    print('content batch',len(ids),'done',flush=True)
    return out
if __name__=='__main__':
    (ROOT/'batches').mkdir(exist_ok=True)
    site=api(meta='siteinfo',siprop='general|namespaces|statistics')
    save('siteinfo.json',site)
    if (ROOT/'inventory.json').exists(): inv=json.loads((ROOT/'inventory.json').read_text())
    else:
        namespaces=[int(x) for x in site['query']['namespaces'] if int(x)>=0]
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
            inv=[p for group in ex.map(inventory,namespaces) for p in group]
        save('inventory.json',inv)
    ids=[p['pageid'] for p in inv if p['ns'] in (0,4,8,10,12,14)]
    pages={}
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
        for b in ex.map(batch,[ids[i:i+20] for i in range(0,len(ids),20)]): pages.update(b)
    save('pages.json',pages)
    files=[];cont={}
    while True:
        d=api(list='allimages',ailimit=500,aiprop='size|url|sha1|mime|timestamp',**cont)
        files+=d.get('query',{}).get('allimages',[])
        if 'continue' not in d: break
        cont=d['continue']
    save('files.json',files)
    print('COMPLETE',len(inv),'inventory entries',len(pages),'content pages',len(files),'files',flush=True)
