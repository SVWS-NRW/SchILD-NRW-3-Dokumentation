import json,re,pathlib,collections,urllib.parse
R=pathlib.Path(__file__).parent
def read(n):return json.loads((R/n).read_text())
def save(n,d):(R/n).write_text(json.dumps(d,ensure_ascii=False,indent=2))
P=read('pages.json');scope=read('scope-pages.json');active={v['title'] for v in scope if v['status'] in ('schild3','reporting','reporting-reference','reporting-archive-review','unfinished-review','alias')}
videos=[];urls=collections.defaultdict(set);malformed=[]
for p in P.values():
 if p['ns']!=0:continue
 w=p['revisions'][0]['slots']['main']['*']
 if p['title'] in active:
  for m in re.finditer(r'<youtube\b[^>]*>(.*?)</youtube>',w,re.I|re.S):
   original=m.group(1);v=original.strip();match=re.match(r'([A-Za-z0-9_-]{11})',v)
   videos.append(dict(page=p['title'],raw_id=original,video_id=match.group(1) if match else None,url='https://www.youtube.com/watch?v='+match.group(1) if match else None,needs_repair=not re.fullmatch(r'[A-Za-z0-9_-]{11}',original)))
  for u in re.findall(r'https?://[^\s<>\]\["{}]+',w):urls[u].add(p['title'])
  for i,line in enumerate(w.splitlines(),1):
   if re.fullmatch(r'\s*\[\[(?:Datei|File):\s*',line):malformed.append(dict(page=p['title'],line=i,issue='Unvollständiger Dateiverweis'))
save('videos.json',videos);save('raw-url-occurrences.json',[dict(raw_url=u,used_by=sorted(ts),note='Quelltextvorkommen, kann Beispieladresse oder fehlerhafte Syntax sein; nicht automatisch abrufen') for u,ts in sorted(urls.items())]);save('malformed-source.json',malformed)
sidebar=json.loads(read('repo-sidebar.json')['content']);items=[]
def walk(nodes):
 for n in nodes:
  if 'link'in n:items.append(dict(text=n['text'],link=n['link']))
  walk(n.get('items',[]))
walk(sidebar)
def key(t):return re.sub(r'\s+',' ',re.sub(r'[:/\\?*<>|_]',' ',t)).strip().casefold()
by=collections.defaultdict(list)
for p in scope:by[key(p['title'])].append(p['title'])
for v in items:v['wiki_candidates']=by.get(key(v['text']),[]);v['match']='sanitized-title-candidate' if v['wiki_candidates'] else 'no-current-title-match'
save('sidebar-comparison.json',dict(note='Nur Vergleich normalisierter Titel, keine bewiesene URL-Zuordnung. Im Git-Baum sind keine Artikeldateien vorhanden.',items=items))
print('VIDEOS',len(videos),'UNIQUE',len({v['video_id'] for v in videos}),'SIDEBAR',len(items),'MATCHED',sum(bool(v['wiki_candidates']) for v in items),'RAW URLS',len(urls))
