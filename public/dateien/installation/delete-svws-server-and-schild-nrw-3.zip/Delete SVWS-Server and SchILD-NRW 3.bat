::Die Bildschirmausgabe wird sinnvoll reduziert und auf UTF8-Ausgabe gestellt
@echo OFF
setlocal EnableDelayedExpansion
chcp 65001 >nul

::Definition der Installationspfade. Falls notwendig, bitte anpassen
set "svwsOrdner=C:\Program Files\SVWS-Server"
set "svwsDataOrdner=C:\ProgramData\SVWS-Server"
set "schildOrdner=C:\Program Files (x86)\SchILD-NRW3"
set "conOrdner=C:\SVWS-Arbeitsverzeichnis\Connection-Files"

echo ---------------------------------------------------------------------------------
echo Bitte schliessen Sie das Fenster, wenn die Batch-Datei nicht im 
echo Administratormodus gestartet wurde. Dateien koennen sonst nicht geloescht werden.
echo ---------------------------------------------------------------------------------
echo.

set /p svws=Wollen Sie den SVWS-Server in den Ordnern %svwsOrdner% und %svwsDataOrdner% deinstallieren [j/n]
echo.

set /p schild=Wollen Sie SchILD-NRW 3 in dem Ordnern %schildOrdner% deinstallieren [j/n]
echo.

set /p con=Wollen Sie alle con-Dateien im Ordner %conOrdner% löschen [j/n]
echo.

::Je nach Eingabe wird nun der SVWS-Server deinstalliert
if /i "%svws%" == "j" (

	echo Stoppe den SVWS-Server Hintergrunddienst
	sc stop svws_server_service
	timeout /T 2 >nul
	
	echo Stoppe den MariaDB Hintergrunddienst
	sc stop svws_server_mariadb
	timeout /T 2 >nul
	
	echo Lösche den SVWS-Server Hintergrunddienst
	sc delete svws_server_service
	timeout /T 1 >nul
	
	echo Lösche den MariaDB Hintergrunddienst
	sc delete svws_server_mariadb
	timeout /T 1 >nul

	echo Lösche die Einträge des SVWS-Servers in der Registry
	reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\SVWSServer" /va  /f
	reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\SVWS Server_is1" /va /f
	timeout /T 2 >nul

	if exist "!svwsDataOrdner!" (
		echo Lösche den Ordner !svwsDataOrdner!
		rmdir /S /Q "!svwsDataOrdner!"
		timeout /T 1 >nul
	) else (
		echo Der Ordner !svwsDataOrdner! konnte nicht gelöscht werden, da er nicht existiert
		timeout /T 1 >nul
	)

	if exist "!svwsOrdner!" (
		echo Lösche den Ordner !svwsOrdner!
		rmdir /S /Q "!svwsOrdner!"
		timeout /T 1 >nul
	) else (
		echo Der Ordner !svwsOrdner! konnte nicht gelöscht werden, da er nicht existiert.
		timeout /T 1 >nul
	)

)

::Je nach Eingabe wird nun Schild3 gelöscht
if /i "%schild%" == "j" (

	echo Entferne die Einträge von SchILD-NRW3 in der Registry
	reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\SchILD-NRW3_is1" /va /f
	reg delete "HKEY_CURRENT_USER\Software\Schild3000" /va /f
	timeout /T 2 >nul

	if exist "!schildOrdner!" (
		echo Lösche den Ordner !schildOrdner!
		rmdir /S /Q "!schildOrdner!"
		timeout /T 1 >nul
	) else (
		echo Der Ordner !schildOrdner! konnte nicht gelöscht werden, da er nicht existiert
		timeout /T 1 >nul
	)

)

::Je nach Eingabe werden die Connection-Files gelöscht
if /i "%con%" == "j" (
	
	if exist "!conOrdner!" (
		echo Lösche alle Connection-Files im Ordner !conOrdner!
		del /F /Q "!conOrdner!\*.con"
		timeout /T 1 >nul
	) else (
		echo Es konnten keine Connection-Files gelöscht werden, da der Ordner !conOrdner! nicht existiert
		timeout /T 1 >nul
	)
	
)

echo.
echo Fertig, Sie können das Fenster nun schließen
pause